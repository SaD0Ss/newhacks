import image from './image.jpg';
import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';
import { Button } from '@mui/material';
import { doc, getDoc, getDocs, getFirestore, collection, query, where } from "firebase/firestore";
import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDj5OgO-GJLetg8TTKDADtBUTNQRVuEds8",
  authDomain: "newhacks-b144e.firebaseapp.com",
  projectId: "newhacks-b144e",
  storageBucket: "newhacks-b144e.appspot.com",
  messagingSenderId: "737121549886",
  appId: "1:737121549886:web:e5c6f6efa1743523765b6f"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app)
const rando = Math.floor(Math.random()* 2)

const docRef = query(collection(db, 'articles'), where("id", "==", rando))



function App() {

  const getData = async () => {
    const querySnapshot = await getDocs(docRef);
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    var temp = (doc.id, " => ", doc.data());
    setTitle(temp.title)
    setContent(temp.body)
    console.log(title)
    
    
  });
  }
  const styles = {
    background: {
      height: "100vh",
      width: "100vw",

    },
    title: {
      color: "white",
      textAlign: "center",
      marginTop: "150px",
      fontSize: "60px",
      letterSpacing: '2px',

    },
    positionCont: {
      position: 'absolute',
      left:"0px",
      right:"0px",
      top: "0px",
      color: "white",
      textAlign: "center"
    },
    logo: {
      position: 'absolute',
      left:"40px",
      top: "40px",
      width: "125px",
      height: "125px"

    },
    button: {
      marginTop: '50px'
    
    }
  }
  const [title, setTitle] = React.useState("")
  const [content, setContent] = React.useState("")
  return (
    <div style={styles.background}>
              <img src={logo} style={styles.logo}/>
<img src={image} style={styles.background}/>

<div>
        <div style={styles.positionCont}>

            <div >
                <h1 style={styles.title}>LEARN ABOUT SOMETHING NEW</h1>
                <p>Have you ever wanted to have extensive knowledge about an obscure topic to impress your friends and family? <br/>
                    Click the button below to discover a Wikipedia article about something extremely specific,<br/>
                    and show others your academic prowess!</p>
                <div style={styles.button}>

                <Button variant="contained" onClick={getData}>GENERATE!</Button>
                </div>
            </div>
            <section >
                <h2 id="title">{title}</h2>
                <p id="body">{content}
                </p>

            </section>
        </div>
        </div>
        </div>
  );
}

export default App;
